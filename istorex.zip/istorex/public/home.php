<?php

require_once __DIR__ . '/../controllers/productController.php';

$controller = new ProductController();
$controller->home();
?>