<footer>
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> iStoreX. All rights reserved.</p>
    </div>
</footer>

<script src="../public/js/script.js"></script>
</body>

</html>